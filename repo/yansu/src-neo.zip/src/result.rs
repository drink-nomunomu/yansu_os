pub type Result<T> = core::result::Result<T, &'static str>;
